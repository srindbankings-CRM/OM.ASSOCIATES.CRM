// scripts/setup.js — One-time setup: creates DB tables + admin user
require('dotenv').config();
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

async function setup() {
  console.log('\n🚀 OM Associates CRM — Setup\n');

  const pool = new Pool({
    host:     process.env.DB_HOST     || 'localhost',
    port:     parseInt(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME     || 'om_crm',
    user:     process.env.DB_USER     || 'postgres',
    password: process.env.DB_PASSWORD || '',
  });

  const client = await pool.connect();

  try {
    // 1. Run schema
    console.log('📋 Running database schema…');
    const schema = fs.readFileSync(path.join(__dirname, '../database/schema.sql'), 'utf8');
    await client.query(schema);
    console.log('   ✅ Schema applied');

    // 2. Create admin user
    const email    = process.env.ADMIN_EMAIL    || 'admin@omassociates.com';
    const password = process.env.ADMIN_PASSWORD || 'Admin@2024';
    const name     = process.env.ADMIN_NAME     || 'OM Admin';

    const { rows: [existing] } = await client.query('SELECT id FROM users WHERE email=$1', [email]);
    if (!existing) {
      const hash = await bcrypt.hash(password, parseInt(process.env.BCRYPT_ROUNDS) || 12);
      await client.query(
        `INSERT INTO users (name, email, password_hash, role, is_active)
         VALUES ($1,$2,$3,'admin',TRUE)`,
        [name, email, hash]
      );
      console.log(`   ✅ Admin created: ${email}`);
    } else {
      console.log(`   ℹ️  Admin already exists: ${email}`);
    }

    // 3. Create upload directory
    const uploadDir = process.env.UPLOAD_DIR || './public/uploads';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
      console.log(`   ✅ Upload dir: ${uploadDir}`);
    }

    // 4. Create .env if missing
    if (!fs.existsSync('.env') && fs.existsSync('.env.example')) {
      fs.copyFileSync('.env.example', '.env');
      console.log('   ✅ .env created from .env.example — EDIT IT NOW!');
    }

    console.log('\n✅ Setup complete!\n');
    console.log('🏃 Start the server:');
    console.log('   npm start\n');
    console.log('🔑 Login credentials:');
    console.log(`   Email:    ${email}`);
    console.log(`   Password: ${password}\n`);

  } catch (err) {
    if (err.code === 'ECONNREFUSED' || err.code === '3D000') {
      console.error('\n❌ Cannot connect to PostgreSQL!');
      console.error('   Make sure PostgreSQL is running and .env is configured correctly.\n');
      console.error('   Quick start:');
      console.error('   1. Install PostgreSQL: https://postgresql.org/download');
      console.error(`   2. Create DB:  createdb ${process.env.DB_NAME || 'om_crm'}`);
      console.error('   3. Set DB_PASSWORD in .env');
      console.error('   4. Run: node scripts/setup.js\n');
    } else {
      console.error('\n❌ Setup error:', err.message);
    }
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

setup();
