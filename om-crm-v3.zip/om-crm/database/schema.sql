-- ═══════════════════════════════════════════════════════════════
-- OM Associates CRM — PostgreSQL Schema v3.0
-- Run: psql -U postgres -d om_crm -f schema.sql
-- ═══════════════════════════════════════════════════════════════

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ── USERS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(120) NOT NULL,
  email VARCHAR(200) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role VARCHAR(20) DEFAULT 'member' CHECK (role IN ('admin','manager','member','viewer')),
  avatar_url TEXT,
  phone VARCHAR(20),
  department VARCHAR(80),
  designation VARCHAR(100),
  is_active BOOLEAN DEFAULT TRUE,
  last_login TIMESTAMPTZ,
  preferences JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── CLIENTS ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(200) NOT NULL,
  company VARCHAR(200),
  email VARCHAR(200),
  phone VARCHAR(20),
  alt_phone VARCHAR(20),
  gst_number VARCHAR(20),
  pan_number VARCHAR(12),
  address TEXT,
  city VARCHAR(80),
  state VARCHAR(80),
  pincode VARCHAR(10),
  country VARCHAR(60) DEFAULT 'India',
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active','inactive','prospect','archived')),
  source VARCHAR(60),
  tags TEXT[],
  notes TEXT,
  assigned_to UUID REFERENCES users(id) ON DELETE SET NULL,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── SERVICES ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS services (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  category VARCHAR(80),
  status VARCHAR(30) DEFAULT 'active'
    CHECK (status IN ('active','pending','completed','cancelled','on_hold')),
  start_date DATE,
  end_date DATE,
  rate NUMERIC(12,2) DEFAULT 0,
  rate_type VARCHAR(20) DEFAULT 'monthly'
    CHECK (rate_type IN ('monthly','quarterly','yearly','one-time')),
  assigned_to UUID REFERENCES users(id) ON DELETE SET NULL,
  priority VARCHAR(15) DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high','critical')),
  notes TEXT,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── TASKS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(300) NOT NULL,
  description TEXT,
  client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
  service_id UUID REFERENCES services(id) ON DELETE SET NULL,
  assigned_to UUID REFERENCES users(id) ON DELETE SET NULL,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  status VARCHAR(20) DEFAULT 'pending'
    CHECK (status IN ('pending','in_progress','review','completed','cancelled')),
  priority VARCHAR(15) DEFAULT 'medium'
    CHECK (priority IN ('low','medium','high','critical')),
  due_date DATE,
  completed_at TIMESTAMPTZ,
  tags TEXT[],
  attachments JSONB DEFAULT '[]',
  is_deleted BOOLEAN DEFAULT FALSE,  -- soft delete flag (hidden from CRM UI)
  deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── INVOICES ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  invoice_number VARCHAR(30) UNIQUE NOT NULL,
  client_id UUID REFERENCES clients(id) ON DELETE RESTRICT,
  service_id UUID REFERENCES services(id) ON DELETE SET NULL,
  title VARCHAR(200),
  line_items JSONB NOT NULL DEFAULT '[]',
  subtotal NUMERIC(14,2) NOT NULL DEFAULT 0,
  discount_type VARCHAR(10) DEFAULT 'percent' CHECK (discount_type IN ('percent','flat')),
  discount_value NUMERIC(10,2) DEFAULT 0,
  tax_rate NUMERIC(5,2) DEFAULT 18,
  tax_amount NUMERIC(14,2) DEFAULT 0,
  total NUMERIC(14,2) NOT NULL DEFAULT 0,
  currency VARCHAR(5) DEFAULT 'INR',
  status VARCHAR(20) DEFAULT 'draft'
    CHECK (status IN ('draft','sent','paid','overdue','cancelled','partial')),
  due_date DATE,
  paid_date DATE,
  paid_amount NUMERIC(14,2) DEFAULT 0,
  payment_method VARCHAR(40),
  notes TEXT,
  terms TEXT,
  logo_url TEXT,
  website TEXT,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── DOCUMENTS ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(300) NOT NULL,
  original_name VARCHAR(300),
  file_path TEXT NOT NULL,
  file_url TEXT,
  file_size BIGINT,
  mime_type VARCHAR(120),
  extension VARCHAR(20),
  client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
  service_id UUID REFERENCES services(id) ON DELETE SET NULL,
  category VARCHAR(80),
  tags TEXT[],
  description TEXT,
  uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
  download_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── MESSAGES ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  room_id VARCHAR(120) NOT NULL,
  sender_id UUID REFERENCES users(id) ON DELETE SET NULL,
  content TEXT,
  type VARCHAR(20) DEFAULT 'text'
    CHECK (type IN ('text','file','image','system','note')),
  file_url TEXT,
  file_name VARCHAR(300),
  is_read BOOLEAN DEFAULT FALSE,
  read_by UUID[],
  is_deleted BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── ATTENDANCE ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS attendance (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  check_in TIMESTAMPTZ,
  check_out TIMESTAMPTZ,
  duration_minutes INT,
  status VARCHAR(20) DEFAULT 'present'
    CHECK (status IN ('present','absent','half_day','leave','holiday','remote')),
  location_in TEXT,
  location_out TEXT,
  notes TEXT,
  approved_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, date)
);

-- ── NOTIFICATIONS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(200) NOT NULL,
  body TEXT NOT NULL,
  type VARCHAR(30) DEFAULT 'info'
    CHECK (type IN ('info','success','warning','error','reminder','broadcast')),
  target_type VARCHAR(20) DEFAULT 'all'
    CHECK (target_type IN ('all','user','role','department')),
  target_id UUID,
  channels TEXT[] DEFAULT '{push}',
  is_read BOOLEAN DEFAULT FALSE,
  read_by UUID[],
  sent_at TIMESTAMPTZ,
  scheduled_at TIMESTAMPTZ,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── IDEAS / CONTENT ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS content_ideas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(300) NOT NULL,
  body TEXT,
  type VARCHAR(30) DEFAULT 'text'
    CHECK (type IN ('text','image','poster','youtube','link','file')),
  url TEXT,
  file_path TEXT,
  thumbnail_url TEXT,
  tags TEXT[],
  is_pinned BOOLEAN DEFAULT FALSE,
  is_published BOOLEAN DEFAULT TRUE,
  display_order INT DEFAULT 0,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── EXPENSES ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(200) NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  category VARCHAR(80),
  date DATE NOT NULL,
  paid_by UUID REFERENCES users(id) ON DELETE SET NULL,
  client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
  receipt_url TEXT,
  notes TEXT,
  status VARCHAR(20) DEFAULT 'pending'
    CHECK (status IN ('pending','approved','rejected','reimbursed')),
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── AI CODE GENERATIONS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_code_generations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  prompt TEXT NOT NULL,
  generated_code TEXT,
  language VARCHAR(30),
  module_name VARCHAR(100),
  status VARCHAR(20) DEFAULT 'pending'
    CHECK (status IN ('pending','generated','tested','deployed','failed','rolled_back')),
  test_output TEXT,
  error_log TEXT,
  version INT DEFAULT 1,
  parent_id UUID REFERENCES ai_code_generations(id) ON DELETE SET NULL,
  is_deployed BOOLEAN DEFAULT FALSE,
  deployed_at TIMESTAMPTZ,
  created_by UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── ACTIVITY LOGS ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50),
  entity_id UUID,
  details JSONB DEFAULT '{}',
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── SYSTEM SETTINGS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS settings (
  key VARCHAR(120) PRIMARY KEY,
  value JSONB NOT NULL,
  description TEXT,
  updated_by UUID REFERENCES users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── INDEXES FOR PERFORMANCE ──────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_clients_status ON clients(status);
CREATE INDEX IF NOT EXISTS idx_clients_assigned ON clients(assigned_to);
CREATE INDEX IF NOT EXISTS idx_clients_name_trgm ON clients USING GIN (name gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_services_client ON services(client_id);
CREATE INDEX IF NOT EXISTS idx_services_status ON services(status);
CREATE INDEX IF NOT EXISTS idx_tasks_assigned ON tasks(assigned_to);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status, is_deleted);
CREATE INDEX IF NOT EXISTS idx_tasks_client ON tasks(client_id);
CREATE INDEX IF NOT EXISTS idx_invoices_client ON invoices(client_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_number ON invoices(invoice_number);
CREATE INDEX IF NOT EXISTS idx_documents_client ON documents(client_id);
CREATE INDEX IF NOT EXISTS idx_messages_room ON messages(room_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_attendance_user_date ON attendance(user_id, date);
CREATE INDEX IF NOT EXISTS idx_notifications_target ON notifications(target_type, target_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_user ON activity_logs(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activity_logs_entity ON activity_logs(entity_type, entity_id);

-- ── TRIGGERS: auto-update updated_at ────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

DO $$ DECLARE tname TEXT;
BEGIN FOR tname IN SELECT unnest(ARRAY[
  'users','clients','services','tasks','invoices',
  'documents','expenses','content_ideas','settings'
]) LOOP
  EXECUTE format('DROP TRIGGER IF EXISTS trg_%I_upd ON %I', tname, tname);
  EXECUTE format('CREATE TRIGGER trg_%I_upd BEFORE UPDATE ON %I
    FOR EACH ROW EXECUTE FUNCTION update_updated_at()', tname, tname);
END LOOP; END; $$;

-- ── DEFAULT SETTINGS ────────────────────────────────────────────
INSERT INTO settings (key, value, description) VALUES
  ('company', '{"name":"OM Associates","website":"https://omassociates.com","email":"info@omassociates.com","phone":"+91-XXXXXXXXXX","address":"Your Address","gst":"GSTIN","logo":null}', 'Company information'),
  ('invoice', '{"prefix":"INV","start_number":1001,"tax_rate":18,"currency":"INR","terms":"Payment due within 30 days.","notes":"Thank you for your business."}', 'Invoice settings'),
  ('crm', '{"theme":"dark","sidebar_collapsed":false,"notifications_enabled":true,"session_timeout":480}', 'CRM display settings'),
  ('ai', '{"enabled":true,"model":"gpt-4-turbo-preview","max_tokens":4096}', 'AI feature settings')
ON CONFLICT (key) DO NOTHING;

COMMENT ON TABLE tasks IS 'Permanent delete via is_deleted flag — deleted tasks hidden from CRM UI immediately';
COMMENT ON TABLE ai_code_generations IS 'AI-generated code with version control and rollback support';
