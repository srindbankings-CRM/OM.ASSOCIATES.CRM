// server.js — OM Associates CRM — Main Server
require('dotenv').config();
const express     = require('express');
const http        = require('http');
const WebSocket   = require('ws');
const path        = require('path');
const cors        = require('cors');
const helmet      = require('helmet');
const compression = require('compression');
const morgan      = require('morgan');
const rateLimit   = require('express-rate-limit');
const { healthCheck } = require('./src/config/database');
const { cache }   = require('./src/config/redis');
const { errorHandler, notFound } = require('./src/middleware/errorHandler');

const app    = express();
const server = http.createServer(app);

// ── WebSocket Server (real-time sync) ────────────────────────────
const wss = new WebSocket.Server({ server, path: '/ws' });
const clients = new Map(); // userId → Set of WebSocket connections

wss.on('connection', (ws, req) => {
  let userId = null;
  ws.isAlive = true;

  ws.on('pong', () => { ws.isAlive = true; });

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());

      // Auth handshake
      if (msg.type === 'auth') {
        const jwt = require('jsonwebtoken');
        const payload = jwt.verify(msg.token, process.env.JWT_SECRET || 'fallback-dev-secret-change-in-production');
        userId = payload.id;
        if (!clients.has(userId)) clients.set(userId, new Set());
        clients.get(userId).add(ws);
        ws.userId = userId;
        ws.send(JSON.stringify({ type: 'auth_ok', userId }));
        console.log(`[WS] User ${userId} connected (${clients.size} total)`);
        return;
      }

      // Broadcast to all except sender
      if (msg.type === 'broadcast' && userId) {
        broadcast({ ...msg, from: userId }, ws);
      }

      // Room messaging
      if (msg.type === 'message' && userId) {
        broadcast({ type: 'message', room: msg.room, content: msg.content,
                    from: userId, ts: Date.now() });
      }
    } catch (e) {
      ws.send(JSON.stringify({ type: 'error', message: e.message }));
    }
  });

  ws.on('close', () => {
    if (userId && clients.has(userId)) {
      clients.get(userId).delete(ws);
      if (clients.get(userId).size === 0) clients.delete(userId);
    }
  });

  ws.on('error', (e) => console.error('[WS] Error:', e.message));
});

// Heartbeat to detect dead connections
const heartbeat = setInterval(() => {
  wss.clients.forEach(ws => {
    if (!ws.isAlive) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);
wss.on('close', () => clearInterval(heartbeat));

// Broadcast to all connected clients (or specific user)
function broadcast(msg, excludeWs = null) {
  const json = JSON.stringify(msg);
  if (msg.userId) {
    // Send to specific user
    const sockets = clients.get(msg.userId);
    if (sockets) sockets.forEach(ws => { if (ws.readyState === 1) ws.send(json); });
  } else {
    // Send to everyone
    wss.clients.forEach(ws => {
      if (ws !== excludeWs && ws.readyState === 1) ws.send(json);
    });
  }
}

// Make broadcast available to routes
app.locals.broadcast = broadcast;
app.locals.wsClients = clients;

// ── Security & Middleware ─────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'", "'unsafe-inline'", "'unsafe-eval'",
                   "https://unpkg.com", "https://cdnjs.cloudflare.com",
                   "https://www.gstatic.com", "https://fonts.googleapis.com"],
      styleSrc:   ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc:    ["'self'", "https://fonts.gstatic.com"],
      imgSrc:     ["'self'", "data:", "blob:", "https:", "http:"],
      frameSrc:   ["'self'", "https://www.youtube.com", "https://youtube.com"],
      connectSrc: ["'self'", "ws:", "wss:", "https://api.openai.com"],
      mediaSrc:   ["'self'", "blob:"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));

app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? [process.env.BASE_URL, 'http://localhost:3000']
    : true,
  credentials: true,
}));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Rate limiting
app.use('/api/', rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW || 15) * 60 * 1000,
  max:      parseInt(process.env.RATE_LIMIT_MAX    || 200),
  standardHeaders: true, legacyHeaders: false,
  message: { success: false, error: 'Too many requests. Please slow down.' },
}));

// Stricter limit for auth endpoints
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, max: 20,
  message: { success: false, error: 'Too many login attempts.' } }));

// ── Static Files ──────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: process.env.NODE_ENV === 'production' ? '1d' : 0,
  etag: true,
}));
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads'), { maxAge: '7d' }));

// ── API Routes ────────────────────────────────────────────────────
app.use('/api/auth',        require('./src/routes/auth'));
app.use('/api/clients',     require('./src/routes/clients'));
app.use('/api/tasks',       require('./src/routes/tasks'));
app.use('/api/invoices',    require('./src/routes/invoices'));
app.use('/api/documents',   require('./src/routes/documents'));
app.use('/api/attendance',  require('./src/routes/attendance'));
app.use('/api/ai',          require('./src/routes/ai'));

// Users route (inline — simpler)
app.use('/api/users', require('./src/routes/auth')); // reuse for profile
app.get('/api/users', require('./src/middleware/auth').authenticate, async (req, res) => {
  const { query } = require('./src/config/database');
  const { rows } = await query(
    `SELECT id, name, email, role, department, designation, is_active, last_login, created_at FROM users ORDER BY name`
  );
  res.json({ success: true, data: rows });
});

// Services route (inline)
const servicesRouter = require('express').Router();
const { authenticate } = require('./src/middleware/auth');
const { asyncHandler } = require('./src/middleware/errorHandler');
const { query: dbQuery } = require('./src/config/database');

servicesRouter.get('/', authenticate, asyncHandler(async (req, res) => {
  const { client_id, status, search, page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;
  const params = []; let where = 'WHERE 1=1';
  if (client_id) { params.push(client_id); where += ` AND s.client_id=$${params.length}`; }
  if (status)    { params.push(status);    where += ` AND s.status=$${params.length}`; }
  if (search)    { params.push(`%${search}%`); where += ` AND (s.name ILIKE $${params.length} OR s.description ILIKE $${params.length})`; }
  params.push(limit, offset);
  const { rows } = await dbQuery(`
    SELECT s.*, c.name AS client_name, u.name AS assigned_name, COUNT(*) OVER() AS total
    FROM services s
    LEFT JOIN clients c ON c.id=s.client_id
    LEFT JOIN users u   ON u.id=s.assigned_to
    ${where} ORDER BY s.created_at DESC
    LIMIT $${params.length-1} OFFSET $${params.length}
  `, params);
  res.json({ success: true, data: rows, pagination: { page: +page, limit: +limit, total: rows[0]?.total || 0 } });
}));
servicesRouter.post('/', authenticate, asyncHandler(async (req, res) => {
  const { client_id, name, description, category, status, start_date, end_date, rate, rate_type, assigned_to, priority, notes } = req.body;
  if (!client_id || !name) return res.status(400).json({ success: false, error: 'Client and name required' });
  const { rows } = await dbQuery(`
    INSERT INTO services (client_id,name,description,category,status,start_date,end_date,rate,rate_type,assigned_to,priority,notes,created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *
  `, [client_id, name, description, category, status||'active', start_date, end_date, rate||0, rate_type||'monthly', assigned_to, priority||'medium', notes, req.user.id]);
  res.status(201).json({ success: true, data: rows[0] });
}));
servicesRouter.put('/:id', authenticate, asyncHandler(async (req, res) => {
  const f = ['name','description','category','status','start_date','end_date','rate','rate_type','assigned_to','priority','notes'];
  const sets = []; const p = [];
  f.forEach(k => { if (req.body[k] !== undefined) { p.push(req.body[k]); sets.push(`${k}=$${p.length}`); } });
  if (!sets.length) return res.status(400).json({ success: false, error: 'Nothing to update' });
  p.push(req.params.id);
  const { rows } = await dbQuery(`UPDATE services SET ${sets.join(',')} WHERE id=$${p.length} RETURNING *`, p);
  res.json({ success: true, data: rows[0] });
}));
servicesRouter.delete('/:id', authenticate, asyncHandler(async (req, res) => {
  await dbQuery('DELETE FROM services WHERE id=$1', [req.params.id]);
  res.json({ success: true });
}));
app.use('/api/services', servicesRouter);

// Content/Ideas route
const ideasRouter = require('express').Router();
ideasRouter.get('/', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await dbQuery(`SELECT * FROM content_ideas WHERE is_published=TRUE ORDER BY is_pinned DESC, display_order, created_at DESC`);
  res.json({ success: true, data: rows });
}));
ideasRouter.post('/', authenticate, asyncHandler(async (req, res) => {
  const { title, body, type, url, tags, is_pinned } = req.body;
  const { rows } = await dbQuery(
    `INSERT INTO content_ideas (title,body,type,url,tags,is_pinned,created_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [title, body, type||'text', url, tags||[], is_pinned||false, req.user.id]
  );
  res.status(201).json({ success: true, data: rows[0] });
}));
ideasRouter.delete('/:id', authenticate, asyncHandler(async (req, res) => {
  await dbQuery('DELETE FROM content_ideas WHERE id=$1', [req.params.id]);
  res.json({ success: true });
}));
app.use('/api/ideas', ideasRouter);

// Notifications route
const notifRouter = require('express').Router();
notifRouter.get('/', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await dbQuery(
    `SELECT * FROM notifications WHERE target_type='all' OR target_id=$1 ORDER BY created_at DESC LIMIT 50`,
    [req.user.id]
  );
  res.json({ success: true, data: rows });
}));
notifRouter.post('/', authenticate, asyncHandler(async (req, res) => {
  if (req.user.role !== 'admin' && req.user.role !== 'manager')
    return res.status(403).json({ success: false, error: 'Not authorized' });
  const { title, body, type, target_type, target_id, channels } = req.body;
  const { rows } = await dbQuery(
    `INSERT INTO notifications (title,body,type,target_type,target_id,channels,sent_at,created_by)
     VALUES ($1,$2,$3,$4,$5,$6,NOW(),$7) RETURNING *`,
    [title, body, type||'info', target_type||'all', target_id, channels||['push'], req.user.id]
  );
  // Broadcast via WebSocket
  broadcast({ type: 'notification', data: rows[0] });
  res.status(201).json({ success: true, data: rows[0] });
}));
notifRouter.patch('/:id/read', authenticate, asyncHandler(async (req, res) => {
  await dbQuery(`UPDATE notifications SET is_read=TRUE WHERE id=$1`, [req.params.id]);
  res.json({ success: true });
}));
app.use('/api/notifications', notifRouter);

// Expenses route
const expRouter = require('express').Router();
expRouter.get('/', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await dbQuery(`SELECT e.*, u.name AS paid_by_name, c.name AS client_name FROM expenses e LEFT JOIN users u ON u.id=e.paid_by LEFT JOIN clients c ON c.id=e.client_id ORDER BY e.date DESC LIMIT 100`);
  res.json({ success: true, data: rows });
}));
expRouter.post('/', authenticate, asyncHandler(async (req, res) => {
  const { title, amount, category, date, client_id, notes } = req.body;
  const { rows } = await dbQuery(
    `INSERT INTO expenses (title,amount,category,date,paid_by,client_id,notes,created_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [title, amount, category, date, req.user.id, client_id, notes, req.user.id]
  );
  res.status(201).json({ success: true, data: rows[0] });
}));
app.use('/api/expenses', expRouter);

// Settings route
app.get('/api/settings/:key?', authenticate, asyncHandler(async (req, res) => {
  if (req.params.key) {
    const { rows } = await dbQuery('SELECT * FROM settings WHERE key=$1', [req.params.key]);
    return res.json({ success: true, data: rows[0] });
  }
  const { rows } = await dbQuery('SELECT * FROM settings');
  res.json({ success: true, data: rows });
}));
app.put('/api/settings/:key', authenticate, asyncHandler(async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ success: false, error: 'Admin only' });
  const { value } = req.body;
  const { rows } = await dbQuery(
    `INSERT INTO settings (key,value,updated_by) VALUES ($1,$2::jsonb,$3)
     ON CONFLICT (key) DO UPDATE SET value=$2::jsonb, updated_by=$3, updated_at=NOW() RETURNING *`,
    [req.params.key, JSON.stringify(value), req.user.id]
  );
  await cache.del(`settings:${req.params.key}`);
  res.json({ success: true, data: rows[0] });
}));

// Activity logs
app.get('/api/activity', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await dbQuery(`
    SELECT a.*, u.name AS user_name FROM activity_logs a
    LEFT JOIN users u ON u.id=a.user_id
    ORDER BY a.created_at DESC LIMIT 100
  `);
  res.json({ success: true, data: rows });
}));

// Dashboard stats
app.get('/api/dashboard/stats', authenticate, asyncHandler(async (req, res) => {
  const cached = await cache.get('dashboard:stats');
  if (cached) return res.json(cached);

  const [clients, services, tasks, invoices, users, attendance] = await Promise.all([
    dbQuery(`SELECT COUNT(*) AS total, COUNT(*) FILTER(WHERE status='active') AS active FROM clients`),
    dbQuery(`SELECT COUNT(*) AS total, COUNT(*) FILTER(WHERE status='active') AS active FROM services`),
    dbQuery(`SELECT COUNT(*) AS total, COUNT(*) FILTER(WHERE status='pending' AND is_deleted=FALSE) AS pending, COUNT(*) FILTER(WHERE status='in_progress' AND is_deleted=FALSE) AS in_progress FROM tasks WHERE is_deleted=FALSE`),
    dbQuery(`SELECT COUNT(*) AS total, SUM(total) AS revenue, SUM(CASE WHEN status='paid' THEN total ELSE 0 END) AS paid, SUM(CASE WHEN status='overdue' THEN total ELSE 0 END) AS overdue FROM invoices`),
    dbQuery(`SELECT COUNT(*) AS total, COUNT(*) FILTER(WHERE is_active=TRUE) AS active FROM users`),
    dbQuery(`SELECT COUNT(*) AS present FROM attendance WHERE date=CURRENT_DATE`),
  ]);

  const result = {
    success: true,
    stats: {
      clients:    clients.rows[0],
      services:   services.rows[0],
      tasks:      tasks.rows[0],
      invoices:   invoices.rows[0],
      users:      users.rows[0],
      attendance: attendance.rows[0],
    },
  };
  await cache.set('dashboard:stats', result, 60);
  res.json(result);
}));

// Health check endpoint
app.get('/api/health', async (req, res) => {
  const db    = await healthCheck();
  const redis = await cache.ping();
  const status = db ? 'healthy' : 'degraded';
  res.status(db ? 200 : 503).json({
    status, version: '3.0.0', db, redis,
    uptime: process.uptime(), memory: process.memoryUsage(),
    timestamp: new Date().toISOString(),
  });
});

// ── SPA Fallback — serve frontend for all non-API routes ─────────
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/ws')) {
    return res.status(404).json({ success: false, error: 'API route not found' });
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Error Handlers ────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Start Server ──────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT) || 3000;
server.listen(PORT, async () => {
  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║     OM Associates CRM — Server Started           ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log(`║  🌐 Frontend  : http://localhost:${PORT}             ║`);
  console.log(`║  🔧 Backend   : http://localhost:${PORT}/backend     ║`);
  console.log(`║  🔗 API       : http://localhost:${PORT}/api         ║`);
  console.log(`║  ♻️  WebSocket : ws://localhost:${PORT}/ws            ║`);
  console.log(`║  🏥 Health    : http://localhost:${PORT}/api/health  ║`);
  console.log('╠══════════════════════════════════════════════════╣');

  const dbOk = await healthCheck();
  const rdOk = await cache.ping();
  console.log(`║  📦 PostgreSQL: ${dbOk ? '✅ Connected' : '❌ OFFLINE'}                    ║`);
  console.log(`║  ⚡ Redis     : ${rdOk ? '✅ Connected' : '⚠️  Memory mode'}                ║`);
  console.log('╚══════════════════════════════════════════════════╝\n');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n❌ Port ${PORT} is already in use. Change PORT in .env\n`);
    process.exit(1);
  }
  throw err;
});

process.on('SIGTERM', () => { console.log('[Server] SIGTERM — shutting down'); server.close(() => process.exit(0)); });
process.on('SIGINT',  () => { console.log('[Server] SIGINT — shutting down');  server.close(() => process.exit(0)); });

module.exports = { app, server, broadcast };
