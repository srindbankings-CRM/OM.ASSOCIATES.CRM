// src/middleware/auth.js — JWT authentication middleware
const jwt = require('jsonwebtoken');
const { cache } = require('../config/redis');

const SECRET = process.env.JWT_SECRET || 'fallback-dev-secret-change-in-production';

/**
 * Verify JWT token from Authorization header or cookie.
 * Attaches req.user on success.
 */
async function authenticate(req, res, next) {
  try {
    const token =
      (req.headers.authorization || '').replace(/^Bearer\s+/, '') ||
      req.cookies?.token || '';

    if (!token) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    // Check token blacklist in cache
    const blacklisted = await cache.get(`blacklist:${token.slice(-16)}`);
    if (blacklisted) {
      return res.status(401).json({ success: false, error: 'Token has been revoked' });
    }

    const payload = jwt.verify(token, SECRET);
    req.user = payload;
    req.token = token;
    next();
  } catch (err) {
    const msg = err.name === 'TokenExpiredError' ? 'Session expired' : 'Invalid token';
    return res.status(401).json({ success: false, error: msg });
  }
}

/** Require admin role */
function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ success: false, error: 'Admin access required' });
  }
  next();
}

/** Require admin or manager role */
function requireManager(req, res, next) {
  if (!['admin', 'manager'].includes(req.user?.role)) {
    return res.status(403).json({ success: false, error: 'Manager access required' });
  }
  next();
}

/** Sign a JWT token */
function signToken(payload, expiresIn = process.env.JWT_EXPIRES_IN || '24h') {
  return jwt.sign(payload, SECRET, { expiresIn });
}

/** Add token to blacklist on logout */
async function blacklistToken(token) {
  const ttl = 86400; // 24h
  await cache.set(`blacklist:${token.slice(-16)}`, true, ttl);
}

module.exports = { authenticate, requireAdmin, requireManager, signToken, blacklistToken };
