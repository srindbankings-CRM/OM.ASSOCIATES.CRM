// src/middleware/errorHandler.js — Global error handling
const { query } = require('../config/database');

/**
 * Global error handler — no blank screens, always returns JSON.
 */
function errorHandler(err, req, res, next) {
  const status  = err.status || err.statusCode || 500;
  const message = err.message || 'Internal server error';
  const isProduction = process.env.NODE_ENV === 'production';

  console.error(`[Error] ${req.method} ${req.path} → ${status}: ${message}`);
  if (status === 500 && !isProduction) console.error(err.stack);

  // Log to DB async (don't await, don't fail on DB error)
  if (status >= 500) {
    query(
      `INSERT INTO activity_logs (action, entity_type, details, ip_address)
       VALUES ($1, $2, $3, $4)`,
      ['server_error', 'system',
       JSON.stringify({ method: req.method, path: req.path, error: message }),
       req.ip]
    ).catch(() => {});
  }

  res.status(status).json({
    success: false,
    error: message,
    ...(isProduction ? {} : { stack: err.stack?.split('\n').slice(0, 5) }),
  });
}

/** Wrap async route handlers to catch promise rejections */
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

/** 404 handler */
function notFound(req, res) {
  res.status(404).json({ success: false, error: `Route ${req.method} ${req.path} not found` });
}

module.exports = { errorHandler, asyncHandler, notFound };
