// src/routes/attendance.js — Real-time attendance tracking
const router = require('express').Router();
const { query } = require('../config/database');
const { authenticate, requireManager } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

// POST /api/attendance/checkin
router.post('/checkin', authenticate, asyncHandler(async (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const { location } = req.body;

  // Check if already checked in today
  const { rows: [existing] } = await query(
    `SELECT * FROM attendance WHERE user_id=$1 AND date=$2`, [req.user.id, today]
  );

  if (existing?.check_in && !existing?.check_out) {
    return res.status(400).json({ success: false, error: 'Already checked in. Please check out first.' });
  }

  let result;
  if (!existing) {
    const { rows } = await query(`
      INSERT INTO attendance (user_id, date, check_in, status, location_in)
      VALUES ($1,$2,NOW(),'present',$3) RETURNING *
    `, [req.user.id, today, location]);
    result = rows[0];
  } else {
    // Re-check in after checkout (new shift)
    const { rows } = await query(`
      UPDATE attendance SET check_in=NOW(), check_out=NULL, duration_minutes=NULL, location_in=$1
      WHERE user_id=$2 AND date=$3 RETURNING *
    `, [location, req.user.id, today]);
    result = rows[0];
  }

  res.json({ success: true, data: result, message: `Check-in recorded at ${new Date().toLocaleTimeString()}` });
}));

// POST /api/attendance/checkout
router.post('/checkout', authenticate, asyncHandler(async (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const { location } = req.body;

  const { rows: [record] } = await query(
    `SELECT * FROM attendance WHERE user_id=$1 AND date=$2`, [req.user.id, today]
  );

  if (!record?.check_in) return res.status(400).json({ success: false, error: 'No check-in found for today' });
  if (record.check_out)  return res.status(400).json({ success: false, error: 'Already checked out' });

  const duration = Math.round((Date.now() - new Date(record.check_in).getTime()) / 60000);

  const { rows } = await query(`
    UPDATE attendance SET check_out=NOW(), duration_minutes=$1, location_out=$2
    WHERE user_id=$3 AND date=$4 RETURNING *
  `, [duration, location, req.user.id, today]);

  res.json({
    success: true,
    data: rows[0],
    message: `Check-out recorded. Duration: ${Math.floor(duration/60)}h ${duration%60}m`,
  });
}));

// GET /api/attendance — list
router.get('/', authenticate, asyncHandler(async (req, res) => {
  const { user_id, from, to, page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;
  const params = []; let where = 'WHERE 1=1';

  // Members see only their own
  const targetUser = req.user.role === 'member' ? req.user.id : (user_id || null);
  if (targetUser) { params.push(targetUser); where += ` AND a.user_id=$${params.length}`; }
  if (from) { params.push(from); where += ` AND a.date >= $${params.length}`; }
  if (to)   { params.push(to);   where += ` AND a.date <= $${params.length}`; }

  params.push(limit, offset);
  const { rows } = await query(`
    SELECT a.*, u.name AS user_name, u.department, COUNT(*) OVER() AS total
    FROM attendance a JOIN users u ON u.id=a.user_id
    ${where} ORDER BY a.date DESC, a.check_in DESC
    LIMIT $${params.length-1} OFFSET $${params.length}
  `, params);

  res.json({ success: true, data: rows, pagination: { page: +page, limit: +limit, total: rows[0]?.total || 0 } });
}));

// GET /api/attendance/today
router.get('/today', authenticate, asyncHandler(async (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const { rows } = await query(`
    SELECT a.*, u.name, u.department
    FROM attendance a JOIN users u ON u.id=a.user_id
    WHERE a.date=$1 ORDER BY a.check_in ASC
  `, [today]);
  res.json({ success: true, data: rows, date: today });
}));

module.exports = router;
