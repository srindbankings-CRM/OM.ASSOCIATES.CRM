// src/routes/tasks.js — Task management (permanent delete, no recycle bin in UI)
const router = require('express').Router();
const { query } = require('../config/database');
const { cache } = require('../config/redis');
const { authenticate, requireManager } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

// GET /api/tasks — never returns is_deleted tasks
router.get('/', authenticate, asyncHandler(async (req, res) => {
  const { search, status, priority, assigned_to, client_id, page = 1, limit = 100 } = req.query;
  const offset = (page - 1) * limit;
  const params = [];
  let where = 'WHERE t.is_deleted = FALSE'; // NEVER show deleted

  if (search) { params.push(`%${search}%`); where += ` AND t.title ILIKE $${params.length}`; }
  if (status)      { params.push(status);      where += ` AND t.status = $${params.length}`; }
  if (priority)    { params.push(priority);    where += ` AND t.priority = $${params.length}`; }
  if (assigned_to) { params.push(assigned_to); where += ` AND t.assigned_to = $${params.length}`; }
  if (client_id)   { params.push(client_id);   where += ` AND t.client_id = $${params.length}`; }

  // Non-admin members only see their assigned tasks
  if (req.user.role === 'member' || req.user.role === 'viewer') {
    params.push(req.user.id);
    where += ` AND t.assigned_to = $${params.length}`;
  }

  params.push(limit, offset);
  const { rows } = await query(`
    SELECT t.*,
      c.name AS client_name,
      u1.name AS assigned_name,
      u2.name AS created_by_name,
      COUNT(*) OVER() AS total_count
    FROM tasks t
    LEFT JOIN clients c  ON c.id = t.client_id
    LEFT JOIN users u1   ON u1.id = t.assigned_to
    LEFT JOIN users u2   ON u2.id = t.created_by
    ${where}
    ORDER BY
      CASE t.priority WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END,
      t.due_date ASC NULLS LAST, t.created_at DESC
    LIMIT $${params.length - 1} OFFSET $${params.length}
  `, params);

  res.json({ success: true, data: rows, pagination: { page: +page, limit: +limit, total: rows[0]?.total_count || 0 } });
}));

// POST /api/tasks
router.post('/', authenticate, asyncHandler(async (req, res) => {
  const { title, description, client_id, service_id, assigned_to,
          status, priority, due_date, tags } = req.body;
  if (!title) return res.status(400).json({ success: false, error: 'Title required' });

  const { rows } = await query(`
    INSERT INTO tasks (title,description,client_id,service_id,assigned_to,
      status,priority,due_date,tags,created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *
  `, [title, description, client_id, service_id, assigned_to || req.user.id,
      status || 'pending', priority || 'medium', due_date, tags || [], req.user.id]);

  await cache.invalidate('tasks:');
  await logAct(req.user.id, 'create', rows[0].id, { title }, req.ip);
  res.status(201).json({ success: true, data: rows[0] });
}));

// PUT /api/tasks/:id
router.put('/:id', authenticate, asyncHandler(async (req, res) => {
  const fields = ['title','description','client_id','service_id','assigned_to',
                  'status','priority','due_date','tags'];
  const updates = []; const params = [];

  fields.forEach(f => {
    if (req.body[f] !== undefined) { params.push(req.body[f]); updates.push(`${f}=$${params.length}`); }
  });
  // Auto-set completed_at when status becomes 'completed'
  if (req.body.status === 'completed') updates.push('completed_at = NOW()');
  if (req.body.status && req.body.status !== 'completed') updates.push('completed_at = NULL');

  if (!updates.length) return res.status(400).json({ success: false, error: 'No fields' });
  params.push(req.params.id);

  const { rows } = await query(
    `UPDATE tasks SET ${updates.join(',')} WHERE id=$${params.length} AND is_deleted=FALSE RETURNING *`, params
  );
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Task not found' });

  await cache.invalidate('tasks:');
  await logAct(req.user.id, 'update', rows[0].id, {}, req.ip);
  res.json({ success: true, data: rows[0] });
}));

// DELETE /api/tasks/:id — permanent delete, immediately gone from CRM UI
router.delete('/:id', authenticate, requireManager, asyncHandler(async (req, res) => {
  // Mark as deleted (is_deleted=true) so it vanishes from all CRM views instantly
  const { rows } = await query(
    `UPDATE tasks SET is_deleted=TRUE, deleted_at=NOW() WHERE id=$1 AND is_deleted=FALSE RETURNING id, title`,
    [req.params.id]
  );
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Task not found' });

  await cache.invalidate('tasks:');
  await logAct(req.user.id, 'delete', req.params.id, { title: rows[0].title }, req.ip);
  res.json({ success: true, message: 'Task permanently removed' });
}));

async function logAct(userId, action, entityId, details, ip) {
  await query(
    `INSERT INTO activity_logs (user_id,action,entity_type,entity_id,details,ip_address)
     VALUES ($1,$2,'task',$3,$4,$5)`,
    [userId, action, entityId, JSON.stringify(details), ip]
  ).catch(() => {});
}

module.exports = router;
