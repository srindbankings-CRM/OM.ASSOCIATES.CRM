// src/routes/documents.js — Document upload + preview
const router = require('express').Router();
const multer = require('multer');
const path   = require('path');
const fs     = require('fs');
const { v4: uuidv4 } = require('uuid');
const { query } = require('../config/database');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const UPLOAD_DIR = process.env.UPLOAD_DIR || './public/uploads';
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => {
    const ext  = path.extname(file.originalname);
    const name = `${uuidv4()}${ext}`;
    cb(null, name);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: (parseInt(process.env.MAX_FILE_SIZE) || 50) * 1024 * 1024 },
});

// GET /api/documents
router.get('/', authenticate, asyncHandler(async (req, res) => {
  const { client_id, category, search, page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;
  const params = []; let where = 'WHERE 1=1';

  if (client_id) { params.push(client_id); where += ` AND d.client_id=$${params.length}`; }
  if (category)  { params.push(category);  where += ` AND d.category=$${params.length}`; }
  if (search)    { params.push(`%${search}%`); where += ` AND (d.name ILIKE $${params.length} OR d.original_name ILIKE $${params.length})`; }

  params.push(limit, offset);
  const { rows } = await query(`
    SELECT d.*, c.name AS client_name, u.name AS uploaded_by_name, COUNT(*) OVER() AS total
    FROM documents d
    LEFT JOIN clients c ON c.id = d.client_id
    LEFT JOIN users  u ON u.id = d.uploaded_by
    ${where} ORDER BY d.created_at DESC
    LIMIT $${params.length-1} OFFSET $${params.length}
  `, params);

  res.json({ success: true, data: rows, pagination: { page: +page, limit: +limit, total: rows[0]?.total || 0 } });
}));

// POST /api/documents/upload
router.post('/upload', authenticate, upload.single('file'), asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, error: 'No file uploaded' });
  const { client_id, category, description, tags } = req.body;
  const ext = path.extname(req.file.originalname).replace('.', '');
  const fileUrl = `/uploads/${req.file.filename}`;

  const { rows } = await query(`
    INSERT INTO documents (name, original_name, file_path, file_url, file_size, mime_type, extension,
      client_id, category, description, tags, uploaded_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *
  `, [req.file.filename, req.file.originalname, req.file.path, fileUrl,
      req.file.size, req.file.mimetype, ext,
      client_id || null, category, description, tags ? JSON.parse(tags) : [], req.user.id]);

  res.status(201).json({ success: true, data: rows[0] });
}));

// GET /api/documents/:id/download
router.get('/:id/download', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT * FROM documents WHERE id=$1`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Document not found' });

  await query(`UPDATE documents SET download_count=download_count+1 WHERE id=$1`, [req.params.id]);

  if (!fs.existsSync(rows[0].file_path)) {
    return res.status(404).json({ success: false, error: 'File not found on disk' });
  }
  res.download(rows[0].file_path, rows[0].original_name);
}));

// DELETE /api/documents/:id
router.delete('/:id', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await query(`DELETE FROM documents WHERE id=$1 RETURNING *`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Not found' });
  fs.unlink(rows[0].file_path, () => {});
  res.json({ success: true });
}));

module.exports = router;
