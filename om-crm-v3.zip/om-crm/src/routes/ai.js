// src/routes/ai.js — AI Code Generation Feature
const router  = require('express').Router();
const { query } = require('../config/database');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const OPENAI_KEY   = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4-turbo-preview';

// ── Internal: call OpenAI API ──────────────────────────────────
async function callOpenAI(messages, max_tokens = 4096) {
  if (!OPENAI_KEY) throw new Error('OpenAI API key not configured');

  const resp = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENAI_KEY}`,
    },
    body: JSON.stringify({ model: OPENAI_MODEL, max_tokens, temperature: 0.3, messages }),
  });

  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.error?.message || `OpenAI API error ${resp.status}`);
  }
  const data = await resp.json();
  return data.choices[0].message.content;
}

// POST /api/ai/generate — Generate code from a prompt
router.post('/generate', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const { prompt, language = 'javascript', module_name } = req.body;
  if (!prompt?.trim()) return res.status(400).json({ success: false, error: 'Prompt required' });

  const systemPrompt = `You are an expert full-stack developer for the OM Associates CRM system.
The CRM uses: Node.js + Express (backend), HTML/CSS/JS (frontend), PostgreSQL, Redis.
When generating code:
1. Write clean, production-ready, well-commented code in ${language}
2. Include error handling
3. For Express routes, follow RESTful conventions
4. For frontend, use vanilla JS/HTML/CSS matching the existing CRM dark theme
5. Return ONLY the code without any markdown fences or explanation
6. Add a brief /* MODULE: description */ comment at the top`;

  let generated_code;
  try {
    generated_code = await callOpenAI([
      { role: 'system', content: systemPrompt },
      { role: 'user',   content: `Generate ${language} code for: ${prompt}` },
    ]);
  } catch (aiErr) {
    return res.status(503).json({ success: false, error: `AI error: ${aiErr.message}` });
  }

  const { rows } = await query(`
    INSERT INTO ai_code_generations (prompt, generated_code, language, module_name, status, created_by)
    VALUES ($1,$2,$3,$4,'generated',$5) RETURNING *
  `, [prompt, generated_code, language, module_name, req.user.id]);

  res.json({ success: true, data: rows[0] });
}));

// POST /api/ai/test/:id — Run basic syntax validation + test
router.post('/test/:id', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT * FROM ai_code_generations WHERE id=$1`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Not found' });

  const gen = rows[0];
  let test_output = '';
  let status = 'tested';

  try {
    // Syntax check for JS
    if (gen.language === 'javascript' || gen.language === 'js') {
      new Function(gen.generated_code); // will throw on syntax error
      test_output = '✅ Syntax validation passed\n✅ No obvious errors detected\n📋 Code is ready for review\n\nTest time: ' + new Date().toISOString();
    } else {
      test_output = `✅ Code generated (${gen.language})\n📋 Manual review recommended for non-JS code\n\nGenerated: ${new Date().toISOString()}`;
    }
  } catch (syntaxErr) {
    status = 'failed';
    test_output = `❌ Syntax Error: ${syntaxErr.message}\n\nLine reference: ${syntaxErr.lineNumber || 'unknown'}\n\nPlease review the generated code.`;
  }

  const { rows: [updated] } = await query(`
    UPDATE ai_code_generations SET status=$1, test_output=$2 WHERE id=$3 RETURNING *
  `, [status, test_output, req.params.id]);

  res.json({ success: true, data: updated });
}));

// POST /api/ai/fix/:id — Auto-fix errors using AI
router.post('/fix/:id', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT * FROM ai_code_generations WHERE id=$1`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Not found' });

  const gen = rows[0];
  const fixPrompt = `The following ${gen.language} code has an error:

ERROR: ${gen.error_log || gen.test_output}

CODE:
${gen.generated_code}

Fix all errors and return ONLY the corrected code:`;

  let fixed_code;
  try {
    fixed_code = await callOpenAI([
      { role: 'system', content: 'You are a code debugging expert. Return ONLY corrected code, no markdown.' },
      { role: 'user',   content: fixPrompt },
    ]);
  } catch (aiErr) {
    return res.status(503).json({ success: false, error: `AI fix error: ${aiErr.message}` });
  }

  // Save as new version
  const { rows: [newVersion] } = await query(`
    INSERT INTO ai_code_generations (prompt, generated_code, language, module_name, status, parent_id, version, created_by)
    SELECT prompt, $1, language, module_name, 'generated', id, version+1, $2
    FROM ai_code_generations WHERE id=$3 RETURNING *
  `, [fixed_code, req.user.id, req.params.id]);

  res.json({ success: true, data: newVersion, message: 'Fixed version created' });
}));

// POST /api/ai/deploy/:id — Deploy to frontend modules
router.post('/deploy/:id', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT * FROM ai_code_generations WHERE id=$1`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Not found' });

  const gen = rows[0];
  if (gen.status !== 'tested')
    return res.status(400).json({ success: false, error: 'Code must pass tests before deployment' });

  const { rows: [deployed] } = await query(`
    UPDATE ai_code_generations
    SET status='deployed', is_deployed=TRUE, deployed_at=NOW()
    WHERE id=$1 RETURNING *
  `, [req.params.id]);

  // Log the deployment
  await query(`
    INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details)
    VALUES ($1, 'ai_deploy', 'ai_code', $2, $3)
  `, [req.user.id, req.params.id, JSON.stringify({ module_name: gen.module_name, language: gen.language })]);

  res.json({ success: true, data: deployed, message: `Module "${gen.module_name || 'unnamed'}" deployed successfully` });
}));

// POST /api/ai/rollback/:id — Rollback to parent version
router.post('/rollback/:id', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT * FROM ai_code_generations WHERE id=$1`, [req.params.id]);
  if (!rows[0] || !rows[0].parent_id)
    return res.status(400).json({ success: false, error: 'No parent version to rollback to' });

  await query(`UPDATE ai_code_generations SET status='rolled_back' WHERE id=$1`, [req.params.id]);
  const { rows: [parent] } = await query(`SELECT * FROM ai_code_generations WHERE id=$1`, [rows[0].parent_id]);

  res.json({ success: true, data: parent, message: 'Rolled back to previous version' });
}));

// GET /api/ai/list — List all generations
router.get('/list', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;
  const { rows } = await query(`
    SELECT g.*, u.name AS created_by_name, COUNT(*) OVER() AS total
    FROM ai_code_generations g
    LEFT JOIN users u ON u.id = g.created_by
    ORDER BY g.created_at DESC
    LIMIT $1 OFFSET $2
  `, [limit, offset]);
  res.json({ success: true, data: rows, pagination: { page: +page, limit: +limit, total: rows[0]?.total || 0 } });
}));

// GET /api/ai/:id — Get single generation
router.get('/:id', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const { rows } = await query(`SELECT * FROM ai_code_generations WHERE id=$1`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Not found' });
  res.json({ success: true, data: rows[0] });
}));

// GET /api/ai/versions/:id — Get all versions in chain
router.get('/versions/:id', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const { rows } = await query(`
    WITH RECURSIVE chain AS (
      SELECT * FROM ai_code_generations WHERE id=$1
      UNION ALL
      SELECT g.* FROM ai_code_generations g JOIN chain c ON g.id = c.parent_id
    )
    SELECT * FROM chain ORDER BY version DESC
  `, [req.params.id]);
  res.json({ success: true, data: rows });
}));

module.exports = router;
