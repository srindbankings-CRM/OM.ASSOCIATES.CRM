// src/routes/invoices.js — Invoice management with auto-calculation
const router = require('express').Router();
const { query } = require('../config/database');
const { cache } = require('../config/redis');
const { authenticate, requireManager } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

// Auto-calculate invoice totals
function calcInvoice(line_items, discount_type, discount_value, tax_rate) {
  const subtotal = line_items.reduce((sum, item) => {
    return sum + (parseFloat(item.quantity || 1) * parseFloat(item.rate || 0));
  }, 0);

  let discount = 0;
  if (discount_type === 'percent') discount = subtotal * (parseFloat(discount_value || 0) / 100);
  else discount = parseFloat(discount_value || 0);

  const taxable  = subtotal - discount;
  const tax_amt  = taxable * (parseFloat(tax_rate || 0) / 100);
  const total    = taxable + tax_amt;

  return {
    subtotal: +subtotal.toFixed(2),
    discount_amount: +discount.toFixed(2),
    tax_amount: +tax_amt.toFixed(2),
    total: +total.toFixed(2),
  };
}

// Generate next invoice number
async function nextInvoiceNumber() {
  const { rows: [setting] } = await query(`SELECT value FROM settings WHERE key='invoice'`);
  const prefix = setting?.value?.prefix || 'INV';
  const start  = setting?.value?.start_number || 1001;
  const { rows: [last] } = await query(
    `SELECT invoice_number FROM invoices ORDER BY created_at DESC LIMIT 1`
  );
  if (!last) return `${prefix}-${start}`;
  const num = parseInt(last.invoice_number.split('-').pop()) + 1;
  return `${prefix}-${isNaN(num) ? start : num}`;
}

// GET /api/invoices
router.get('/', authenticate, asyncHandler(async (req, res) => {
  const { search, status, client_id, page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;
  const params = []; let where = 'WHERE 1=1';

  if (search) { params.push(`%${search}%`); where += ` AND (i.invoice_number ILIKE $${params.length} OR c.name ILIKE $${params.length})`; }
  if (status)    { params.push(status);    where += ` AND i.status = $${params.length}`; }
  if (client_id) { params.push(client_id); where += ` AND i.client_id = $${params.length}`; }

  // Non-billing roles see only their client invoices
  if (req.user.role === 'member') {
    params.push(req.user.id);
    where += ` AND i.created_by = $${params.length}`;
  }

  params.push(limit, offset);
  const { rows } = await query(`
    SELECT i.*, c.name AS client_name, c.email AS client_email,
           c.gst_number AS client_gst, c.address AS client_address,
           u.name AS created_by_name,
           COUNT(*) OVER() AS total_count
    FROM invoices i
    JOIN clients c ON c.id = i.client_id
    LEFT JOIN users u ON u.id = i.created_by
    ${where}
    ORDER BY i.created_at DESC
    LIMIT $${params.length - 1} OFFSET $${params.length}
  `, params);

  // Summary stats
  const { rows: [stats] } = await query(`
    SELECT
      COUNT(*) AS total,
      SUM(CASE WHEN status='paid' THEN total ELSE 0 END) AS paid_amount,
      SUM(CASE WHEN status='overdue' THEN total ELSE 0 END) AS overdue_amount,
      SUM(CASE WHEN status NOT IN ('paid','cancelled') THEN total ELSE 0 END) AS outstanding
    FROM invoices
  `);

  res.json({ success: true, data: rows, stats, pagination: { page: +page, limit: +limit, total: rows[0]?.total_count || 0 } });
}));

// GET /api/invoices/:id
router.get('/:id', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await query(`
    SELECT i.*, c.name AS client_name, c.email AS client_email, c.phone AS client_phone,
           c.gst_number AS client_gst, c.address AS client_address,
           c.city AS client_city, c.state AS client_state, c.pincode AS client_pincode,
           s.value AS company_settings
    FROM invoices i
    JOIN clients c ON c.id = i.client_id
    CROSS JOIN settings s WHERE s.key = 'company' AND i.id = $1
  `, [req.params.id]);

  if (!rows[0]) return res.status(404).json({ success: false, error: 'Invoice not found' });
  res.json({ success: true, data: rows[0] });
}));

// POST /api/invoices
router.post('/', authenticate, requireManager, asyncHandler(async (req, res) => {
  const { client_id, service_id, title, line_items = [], discount_type = 'percent',
          discount_value = 0, tax_rate, notes, terms, due_date } = req.body;

  if (!client_id) return res.status(400).json({ success: false, error: 'Client required' });
  if (!line_items.length) return res.status(400).json({ success: false, error: 'At least one line item required' });

  // Get tax rate from settings if not provided
  let effectiveTaxRate = tax_rate;
  if (effectiveTaxRate === undefined) {
    const { rows: [s] } = await query(`SELECT value FROM settings WHERE key='invoice'`);
    effectiveTaxRate = s?.value?.tax_rate || 18;
  }

  const calc = calcInvoice(line_items, discount_type, discount_value, effectiveTaxRate);
  const invoice_number = await nextInvoiceNumber();

  const { rows } = await query(`
    INSERT INTO invoices (invoice_number,client_id,service_id,title,line_items,
      subtotal,discount_type,discount_value,tax_rate,tax_amount,total,
      notes,terms,due_date,created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
    RETURNING *
  `, [invoice_number, client_id, service_id, title, JSON.stringify(line_items),
      calc.subtotal, discount_type, discount_value, effectiveTaxRate, calc.tax_amount,
      calc.total, notes, terms, due_date, req.user.id]);

  await cache.invalidate('invoices:');
  res.status(201).json({ success: true, data: rows[0] });
}));

// PUT /api/invoices/:id
router.put('/:id', authenticate, requireManager, asyncHandler(async (req, res) => {
  const { line_items, discount_type, discount_value, tax_rate, status,
          notes, terms, due_date, paid_date, paid_amount, payment_method } = req.body;

  let calc = {};
  if (line_items) {
    calc = calcInvoice(line_items, discount_type, discount_value, tax_rate);
  }

  const params = [req.params.id];
  const sets = [];

  if (line_items)      { params.push(JSON.stringify(line_items)); sets.push(`line_items=$${params.length}`); }
  if (calc.subtotal)   { params.push(calc.subtotal);   sets.push(`subtotal=$${params.length}`); }
  if (calc.tax_amount) { params.push(calc.tax_amount); sets.push(`tax_amount=$${params.length}`); }
  if (calc.total)      { params.push(calc.total);      sets.push(`total=$${params.length}`); }
  if (discount_type)   { params.push(discount_type);   sets.push(`discount_type=$${params.length}`); }
  if (discount_value !== undefined) { params.push(discount_value); sets.push(`discount_value=$${params.length}`); }
  if (tax_rate !== undefined) { params.push(tax_rate); sets.push(`tax_rate=$${params.length}`); }
  if (status)          { params.push(status);          sets.push(`status=$${params.length}`); }
  if (notes)           { params.push(notes);           sets.push(`notes=$${params.length}`); }
  if (terms)           { params.push(terms);           sets.push(`terms=$${params.length}`); }
  if (due_date)        { params.push(due_date);        sets.push(`due_date=$${params.length}`); }
  if (paid_date)       { params.push(paid_date);       sets.push(`paid_date=$${params.length}`); }
  if (paid_amount)     { params.push(paid_amount);     sets.push(`paid_amount=$${params.length}`); }
  if (payment_method)  { params.push(payment_method);  sets.push(`payment_method=$${params.length}`); }

  if (!sets.length) return res.status(400).json({ success: false, error: 'Nothing to update' });

  const { rows } = await query(
    `UPDATE invoices SET ${sets.join(',')} WHERE id=$1 RETURNING *`, params
  );
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Invoice not found' });

  await cache.invalidate('invoices:');
  res.json({ success: true, data: rows[0] });
}));

module.exports = router;
