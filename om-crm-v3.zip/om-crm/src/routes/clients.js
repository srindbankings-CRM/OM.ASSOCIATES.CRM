// src/routes/clients.js — Client CRUD endpoints
const router = require('express').Router();
const { query, transaction } = require('../config/database');
const { cache } = require('../config/redis');
const { authenticate, requireManager } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const CACHE_TTL = 120;

// GET /api/clients  — list with search + filter
router.get('/', authenticate, asyncHandler(async (req, res) => {
  const { search = '', status, page = 1, limit = 50, assigned_to } = req.query;
  const offset = (page - 1) * limit;

  const cacheKey = `clients:${JSON.stringify(req.query)}`;
  const cached = await cache.get(cacheKey);
  if (cached) return res.json(cached);

  const params = [];
  let where = 'WHERE 1=1';

  if (search) {
    params.push(`%${search}%`);
    where += ` AND (c.name ILIKE $${params.length} OR c.company ILIKE $${params.length}
                   OR c.email ILIKE $${params.length} OR c.phone ILIKE $${params.length}
                   OR c.gst_number ILIKE $${params.length})`;
  }
  if (status) { params.push(status); where += ` AND c.status = $${params.length}`; }
  if (assigned_to) { params.push(assigned_to); where += ` AND c.assigned_to = $${params.length}`; }

  params.push(limit, offset);
  const { rows } = await query(`
    SELECT c.*, u.name AS assigned_name,
           COUNT(*) OVER() AS total_count,
           (SELECT COUNT(*) FROM services s WHERE s.client_id = c.id) AS service_count,
           (SELECT COUNT(*) FROM invoices i WHERE i.client_id = c.id) AS invoice_count
    FROM clients c
    LEFT JOIN users u ON u.id = c.assigned_to
    ${where}
    ORDER BY c.created_at DESC
    LIMIT $${params.length - 1} OFFSET $${params.length}
  `, params);

  const result = {
    success: true,
    data: rows,
    pagination: { page: +page, limit: +limit, total: rows[0]?.total_count || 0 },
  };
  await cache.set(cacheKey, result, CACHE_TTL);
  res.json(result);
}));

// GET /api/clients/:id
router.get('/:id', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await query(`
    SELECT c.*, u.name AS assigned_name,
      json_agg(DISTINCT s.*) FILTER (WHERE s.id IS NOT NULL) AS services,
      json_agg(DISTINCT i.*) FILTER (WHERE i.id IS NOT NULL) AS invoices
    FROM clients c
    LEFT JOIN users u ON u.id = c.assigned_to
    LEFT JOIN services s ON s.client_id = c.id
    LEFT JOIN invoices i ON i.client_id = c.id
    WHERE c.id = $1
    GROUP BY c.id, u.name
  `, [req.params.id]);

  if (!rows[0]) return res.status(404).json({ success: false, error: 'Client not found' });
  res.json({ success: true, data: rows[0] });
}));

// POST /api/clients
router.post('/', authenticate, requireManager, asyncHandler(async (req, res) => {
  const { name, company, email, phone, alt_phone, gst_number, pan_number,
          address, city, state, pincode, country, status, source, tags, notes, assigned_to } = req.body;

  if (!name) return res.status(400).json({ success: false, error: 'Client name is required' });

  const { rows } = await query(`
    INSERT INTO clients (name,company,email,phone,alt_phone,gst_number,pan_number,
      address,city,state,pincode,country,status,source,tags,notes,assigned_to,created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
    RETURNING *
  `, [name, company, email, phone, alt_phone, gst_number, pan_number,
      address, city, state, pincode, country || 'India',
      status || 'active', source, tags || [], notes, assigned_to, req.user.id]);

  await cache.invalidate('clients:');
  await logActivity(req.user.id, 'create', 'client', rows[0].id, { name }, req.ip);
  res.status(201).json({ success: true, data: rows[0] });
}));

// PUT /api/clients/:id
router.put('/:id', authenticate, requireManager, asyncHandler(async (req, res) => {
  const fields = ['name','company','email','phone','alt_phone','gst_number','pan_number',
                  'address','city','state','pincode','country','status','source','tags','notes','assigned_to'];
  const updates = []; const params = [];

  fields.forEach(f => {
    if (req.body[f] !== undefined) {
      params.push(req.body[f]);
      updates.push(`${f} = $${params.length}`);
    }
  });
  if (!updates.length) return res.status(400).json({ success: false, error: 'No fields to update' });

  params.push(req.params.id);
  const { rows } = await query(
    `UPDATE clients SET ${updates.join(',')} WHERE id = $${params.length} RETURNING *`, params
  );
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Client not found' });

  await cache.invalidate('clients:');
  await logActivity(req.user.id, 'update', 'client', rows[0].id, {}, req.ip);
  res.json({ success: true, data: rows[0] });
}));

// DELETE /api/clients/:id  (permanent)
router.delete('/:id', authenticate, requireManager, asyncHandler(async (req, res) => {
  const { rows } = await query('DELETE FROM clients WHERE id=$1 RETURNING id, name', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Client not found' });
  await cache.invalidate('clients:');
  await logActivity(req.user.id, 'delete', 'client', req.params.id, { name: rows[0].name }, req.ip);
  res.json({ success: true, message: 'Client deleted' });
}));

async function logActivity(userId, action, entity, entityId, details, ip) {
  await query(
    `INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details, ip_address)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [userId, action, entity, entityId, JSON.stringify(details), ip]
  ).catch(() => {});
}

module.exports = router;
