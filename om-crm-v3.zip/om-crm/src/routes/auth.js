// src/routes/auth.js — Authentication endpoints
const router   = require('express').Router();
const bcrypt   = require('bcryptjs');
const { query }  = require('../config/database');
const { cache }  = require('../config/redis');
const { signToken, blacklistToken, authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

// POST /api/auth/login
router.post('/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ success: false, error: 'Email and password required' });

  const { rows } = await query(
    'SELECT id, name, email, password_hash, role, is_active, avatar_url, preferences FROM users WHERE email = $1',
    [email.toLowerCase().trim()]
  );
  const user = rows[0];

  if (!user || !user.is_active)
    return res.status(401).json({ success: false, error: 'Invalid credentials or account disabled' });

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid)
    return res.status(401).json({ success: false, error: 'Invalid credentials' });

  // Update last login
  await query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);

  // Log activity
  await query(
    `INSERT INTO activity_logs (user_id, action, entity_type, details, ip_address)
     VALUES ($1, 'login', 'user', $2, $3)`,
    [user.id, JSON.stringify({ email }), req.ip]
  ).catch(() => {});

  const token = signToken({ id: user.id, name: user.name, email: user.email, role: user.role });

  res.json({
    success: true,
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role,
            avatar_url: user.avatar_url, preferences: user.preferences },
  });
}));

// POST /api/auth/logout
router.post('/logout', authenticate, asyncHandler(async (req, res) => {
  await blacklistToken(req.token);
  await query(
    `INSERT INTO activity_logs (user_id, action, entity_type, ip_address)
     VALUES ($1, 'logout', 'user', $2)`,
    [req.user.id, req.ip]
  ).catch(() => {});
  res.json({ success: true, message: 'Logged out' });
}));

// GET /api/auth/me
router.get('/me', authenticate, asyncHandler(async (req, res) => {
  const cacheKey = `user:${req.user.id}`;
  let profile = await cache.get(cacheKey);

  if (!profile) {
    const { rows } = await query(
      `SELECT id, name, email, role, avatar_url, phone, department, designation,
              preferences, last_login, created_at FROM users WHERE id = $1`,
      [req.user.id]
    );
    if (!rows[0]) return res.status(404).json({ success: false, error: 'User not found' });
    profile = rows[0];
    await cache.set(cacheKey, profile, 300);
  }
  res.json({ success: true, user: profile });
}));

// PATCH /api/auth/profile
router.patch('/profile', authenticate, asyncHandler(async (req, res) => {
  const { name, phone, department, designation, preferences } = req.body;
  const { rows } = await query(
    `UPDATE users SET name=$1, phone=$2, department=$3, designation=$4,
     preferences=COALESCE($5::jsonb, preferences)
     WHERE id=$6 RETURNING id, name, email, role, phone, department, designation, preferences`,
    [name, phone, department, designation,
     preferences ? JSON.stringify(preferences) : null, req.user.id]
  );
  await cache.del(`user:${req.user.id}`);
  res.json({ success: true, user: rows[0] });
}));

// POST /api/auth/change-password
router.post('/change-password', authenticate, asyncHandler(async (req, res) => {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password || new_password.length < 8)
    return res.status(400).json({ success: false, error: 'Invalid password data' });

  const { rows } = await query('SELECT password_hash FROM users WHERE id=$1', [req.user.id]);
  const valid = await bcrypt.compare(current_password, rows[0].password_hash);
  if (!valid) return res.status(400).json({ success: false, error: 'Current password incorrect' });

  const hash = await bcrypt.hash(new_password, parseInt(process.env.BCRYPT_ROUNDS) || 12);
  await query('UPDATE users SET password_hash=$1 WHERE id=$2', [hash, req.user.id]);
  res.json({ success: true, message: 'Password updated' });
}));

module.exports = router;
