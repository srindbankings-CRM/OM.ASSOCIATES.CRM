// src/config/redis.js — Redis client with graceful fallback
const Redis = require('ioredis');

let client = null;
let isConnected = false;

// In-memory fallback when Redis is unavailable
const memCache = new Map();
const memExpiry = new Map();

function createClient() {
  const opts = {
    host:        process.env.REDIS_HOST     || 'localhost',
    port:        parseInt(process.env.REDIS_PORT) || 6379,
    password:    process.env.REDIS_PASSWORD || undefined,
    db:          parseInt(process.env.REDIS_DB) || 0,
    maxRetriesPerRequest: 3,
    enableReadyCheck: true,
    lazyConnect: true,
    retryStrategy(times) {
      if (times > 5) return null; // stop retrying
      return Math.min(times * 500, 3000);
    },
  };

  const c = new Redis(opts);
  c.on('connect',  () => { isConnected = true;  console.log('[Redis] Connected'); });
  c.on('error',    (e) => { isConnected = false; console.warn('[Redis] Error (using memory cache):', e.message); });
  c.on('close',    () => { isConnected = false; });
  c.on('reconnecting', () => console.log('[Redis] Reconnecting…'));
  return c;
}

function isExpired(key) {
  const exp = memExpiry.get(key);
  if (!exp) return false;
  if (Date.now() > exp) { memCache.delete(key); memExpiry.delete(key); return true; }
  return false;
}

const cache = {
  /** Get a value. Returns null if missing or expired. */
  async get(key) {
    if (isConnected && client) {
      const v = await client.get(key);
      return v ? JSON.parse(v) : null;
    }
    if (isExpired(key)) return null;
    const v = memCache.get(key);
    return v !== undefined ? v : null;
  },

  /** Set a value with optional TTL in seconds (default 300). */
  async set(key, value, ttl = parseInt(process.env.CACHE_TTL) || 300) {
    const str = JSON.stringify(value);
    if (isConnected && client) {
      await client.setex(key, ttl, str);
    } else {
      memCache.set(key, value);
      memExpiry.set(key, Date.now() + ttl * 1000);
    }
  },

  /** Delete one or more keys (supports glob patterns via Redis). */
  async del(...keys) {
    if (isConnected && client) {
      const multi = client.multi();
      keys.forEach(k => multi.del(k));
      await multi.exec();
    } else {
      keys.forEach(k => { memCache.delete(k); memExpiry.delete(k); });
    }
  },

  /** Invalidate all keys matching a prefix pattern. */
  async invalidate(prefix) {
    if (isConnected && client) {
      const keys = await client.keys(`${prefix}*`);
      if (keys.length) await client.del(...keys);
    } else {
      for (const k of memCache.keys()) {
        if (k.startsWith(prefix)) { memCache.delete(k); memExpiry.delete(k); }
      }
    }
  },

  /** Health check. */
  async ping() {
    if (isConnected && client) {
      const r = await client.ping();
      return r === 'PONG';
    }
    return false; // memory mode
  },
};

// Initialize connection (non-blocking)
try {
  client = createClient();
  client.connect().catch(() => {}); // failures handled by event
} catch (e) {
  console.warn('[Redis] Init failed, using memory cache:', e.message);
}

module.exports = { cache, client: () => client, isConnected: () => isConnected };
