# OM Associates — CRM System

**Finance & Legal CRM** for OM Associates, JAGTIAL, Telangana

## 🔗 Live URLs
- **CRM Login**: `https://om-associates.vercel.app/`
- **Backend Admin**: `https://om-associates.vercel.app/admin`

## 📁 Files
| File | Purpose |
|------|---------|
| `index.html` | Main CRM (staff login, clients, tasks, billing, docs) |
| `admin.html` | Backend Admin Panel (admin only) |
| `vercel.json` | Vercel deployment config |

## 🔐 Default Logins
| Username | Password | Role |
|----------|----------|------|
| `admin` | `Admin@2024` | Super Admin |
| `srinu` | `Srinu@1234` | Admin |

> **Note:** Change passwords from Settings → Users after first login.

## 🚀 Features
- Client & Service Management
- Task Management with Recycle Bin
- Invoice Generator with Logo
- Financial Reports
- WhatsApp Broadcast
- Real-time Attendance (live timer)
- Firebase Sync (real-time across all devices)
- 61+ Text Styles & Dark/Light mode

## ⚡ Tech Stack
- React 18 (via CDN)
- Firebase Realtime Database
- Deployed on Vercel
